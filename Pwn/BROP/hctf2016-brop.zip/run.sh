nohup ./deploy.sh &
